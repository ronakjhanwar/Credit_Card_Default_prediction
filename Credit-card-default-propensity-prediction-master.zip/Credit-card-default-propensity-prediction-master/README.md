# Credit-card-default-propensity-prediction
Predict the probability of a customer defaulting payment for the credit card the subsequent month, based on past information.
